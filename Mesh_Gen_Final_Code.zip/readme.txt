- Run 'MeshGenerator_GUI.m' to acess the GUI and run all codes

- Refer User Guide for details on using GUI
- All sub-function files and '.m' codes should be in the same directory (Extract the complete package as one)
- All geometry files (.obj) need to be in the same directory as well for importing
- All the exported geometry files (.obj) are exported in the parent directory itself
